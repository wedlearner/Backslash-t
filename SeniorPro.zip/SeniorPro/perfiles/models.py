from django.db import models
from django.contrib.auth.models import User

class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nombre = models.CharField(max_length = 30, help_text = 'Nombre completo')
    foto = models.ImageField(upload_to='fotos_perfil/', null = True, blank = True)
    #fecha_nacimiento = models.DateField(null = True, blank = True)
    telefono = models.CharField(max_length = 12, help_text = 'Teléfono')
    localidad = models.CharField(max_length = 30, help_text = 'Localidad')
    descripcion = models.TextField(help_text = 'Incluya información sobre usted para que otros le conozcan')


    def __str__(self):
        return self.nombre
# Create your models here.
