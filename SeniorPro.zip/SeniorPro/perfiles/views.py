from django.shortcuts import render,redirect
from .models import Perfil , User
from django.contrib.auth.decorators import login_required
from .forms import PerfilForm
from django.http import HttpResponse
@login_required
def ver_perfil(request):
    perfil = request.user.perfil
    publicaciones = perfil.servicio_set.all()  
    return render(request, 'perfiles/perfil.html', {
        'perfil': perfil,
        'publicaciones': publicaciones
    })


@login_required
def editar_perfil(request):
    perfil = request.user.perfil
    if request.method == 'POST':
        campos_actualizables = ["nombre", "telefono", "mail", "localidad", "descripcion"]
        for campo in campos_actualizables:
            if campo in request.POST:
                setattr(perfil, campo, request.POST[campo])
        perfil.save()
        return redirect('perfiles:ver_perfil')
    
@login_required
def editar_foto(request):
    perfil = request.user.perfil
    
    if request.method == "POST" and "foto" in request.FILES:
        perfil.foto = request.FILES["foto"]
        perfil.save()
    
    return redirect("perfiles:ver_perfil")

    
@login_required
def administrar_correo(request):
    if request.method == 'POST':
        nuevo_email = request.POST.get('email')
        if "@" in nuevo_email and "." in nuevo_email:
            request.user.email = nuevo_email
            request.user.save()
            return redirect('perfiles:ver_perfil')
        else:
            return redirect('perfiles:ver_perfil')
    else:
        user = request.user
        correo = user.email 
        return HttpResponse(request.user.email)


def tutorial(request):
    if "login_status" in request.COOKIES and "username" in request.COOKIES:
        context = {
            'username': request.COOKIES["username"],
            'login_status': request.COOKIES.get("login_status")
        }
        return render(request, 'perfiles/perfil.html', context)
    else:
        return render(request,'perfiles/tutorial_sesion_cerrada.html')

def tutorial_sesionIniciada(request):
    perfil = request.user.perfil
    return render(
        request,
        'perfiles/tutorial_sesion_iniciada.html',
        {'perfil': perfil}
    )


# Create your views here.
