from django.contrib import admin
from django.urls import path
from . import views

app_name = 'perfiles'

urlpatterns = [
    path('ver_perfil/', views.ver_perfil, name = 'ver_perfil'),
    path('editar_perfil/',views.editar_perfil, name = 'editar_perfil'),
    path('editar_foto/',views.editar_foto, name = 'editar_foto'),
    path('tutorial/', views.tutorial, name= 'tutorial'),
    path('tutorial_sesionIniciada/', views.tutorial_sesionIniciada, name= 'tutorial_sesionIniciada'),
    path('administrar_correo/', views.administrar_correo, name= 'administrar_correo'),
    
]
