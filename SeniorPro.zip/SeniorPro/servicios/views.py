from django.shortcuts import render, redirect, get_object_or_404
from .models import servicio
from django.contrib import messages
from difflib import SequenceMatcher
from django.db.models import Q

def ver_servicios(request):
    q = request.GET.get('q','').strip()
    if q: 
        qs = servicio.objects.filter(
            Q(titulo__icontains=q) | Q(trabajador__nombre__icontains=q) | Q(trabajador__localidad__icontains=q) | Q(descripcion__icontains=q)
        ).distinct()

        def score(srv):
            t = (srv.titulo or '')
            tr = str(srv.trabajador) if srv.trabajador else ''
            loc = (srv.trabajador.localidad if srv.trabajador and getattr(srv.trabajador, 'localidad', None) else '')
            d = (srv.descripcion or '')
            ratios = []
            for field in (t, tr, loc, d):
                try:
                    ratios.append(SequenceMatcher(None, q.lower(), field.lower()).ratio())
                except Exception:
                    ratios.append(0)
            return max(ratios)
        
        servicios_list = list(qs)
        servicios_list.sort(key=score, reverse=True)
        servicios = servicios_list
    else:
        servicios = servicio.objects.all()

    return render (request, 'servicios/ver_servicios.html', {'servicios':servicios})

def agregar_servicio(request):
    if request.method == 'POST':
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')
        precio = request.POST.get('precio')

        nuevo_servicio = servicio.objects.create(
            titulo=titulo,
            trabajador = request.user.perfil,
            descripcion=descripcion,
            precio = precio
        )
        messages.success(request, 'Servicio agregado exitosamente')
        return redirect('perfiles:ver_perfil')
    
    return render(request, 'servicios/agregar_servicio.html')

def editar_servicio(request, servicio_id):
    servicio_obj = get_object_or_404(servicio, id=servicio_id)
    
    if request.method == 'POST':
        servicio_obj.titulo = request.POST.get('titulo')
        servicio_obj.precio = request.POST.get('precio')
        servicio_obj.descripcion = request.POST.get('descripcion')
        servicio_obj.save()
        
        messages.success(request, 'Servicio actualizado exitosamente')
        return redirect('perfiles:ver_perfil')
    
    return render(request, 'servicios/editar_servicio.html', {'servicio': servicio_obj})

def eliminar_servicio(request, servicio_id):
    serv = get_object_or_404(servicio, id=servicio_id)
    if serv.trabajador != request.user.perfil:
        return redirect('perfiles:ver_perfil')
    serv.delete()
    return redirect('perfiles:ver_perfil')


def info_publicacion(request,servicio_id):
    servicio_obj = get_object_or_404(servicio, id=servicio_id)   
    trabajador = servicio_obj.trabajador   
    return render(request, 'servicios/info_publicacion.html', {
        'servicio': servicio_obj,
        'trabajador': trabajador,
    })
